# ExtWebComponents in 1 file

1 - unzip folder contents to folder named oneFile
2 - change directory to oneFile
3 - double-click on index.html
4 - click on the 'INITIAL BUTTON TEXT' button
5 - text should change to 'BUTTON TEXT 1'
